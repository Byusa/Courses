# UserAPI Application

## Overview
This is the UserAPI application, a Python web application built using Flask. It's configured for continuous integration, testing, and deployment using CircleCI and Kubernetes.

## Pre-requisites

1. Docker installed on your local machine.
2. A Kubernetes cluster available (like Minikube for local development).
3. CircleCI CLI installed for local pipeline development.
4. kubectl installed for interacting with the Kubernetes cluster.

## Setup and Running the Application

1. Navigate to the app directory:

```
cd app
```

2. Build the Docker image:

```
docker build -t byusa/userapi:v1.0 .
```


3. Run the Docker container locally:

```
docker run -p 8080:8080 -e MYSQL_SERVICE_PORT="PORT_NUMBER" -e db_root_password="Your_Password" -e db_name="your_DB" -e MYSQL_SERVICE_HOST="host.docker.internal" your_docker_image/userapi:version

```

Now, the API should be available on `localhost:8080`.

## Deploying to Kubernetes

1. If you are using Minikube, start it:
```
minikube start
```

2. Apply the Kubernetes manifests:

```
kubectl apply -f kubernetes/
```

Note: Make sure to update the image location in `deployment.yaml` to `your_docker_image/userapi:version`.

3. Check the deployment and service status:

```
kubectl get all
```

## CI/CD Pipeline

CircleCI is used for the CI/CD pipeline. It is configured to install dependencies, run tests, build the Docker image, and deploy to Kubernetes.

To run the CircleCI pipeline locally, you can use the CircleCI CLI:


```
circleci local execute
```

Please replace `<your_specific_tag>` with your desired Docker image tag.

## Contributing

For any changes, please open an issue first to discuss what you would like to change, then update the tests as appropriate.
