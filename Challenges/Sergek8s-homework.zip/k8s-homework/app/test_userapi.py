import os
import unittest
from userapi import app
import json


class FlaskTest(unittest.TestCase):

    def setUp(self):
        self.tester = app.test_client(self)

    # Ensure that Flask was set up correctly
    def test_index(self):
        response = self.tester.get('/', content_type='html/text')
        self.assertEqual(response.status_code, 200)

    # Ensure that a user is successfully created
    def test_create_user(self):
        response = self.tester.post('/create', data=json.dumps(dict(name='name', email='email', pwd='pwd')), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), "User created successfully!")

    # Ensure that a user is successfully updated
    def test_update_user(self):
        response = self.tester.post('/update', data=json.dumps(dict(name='new name', email='new email', pwd='new pwd', user_id=1)), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), "User updated successfully!")

    # Ensure that a user is successfully deleted
    def test_delete_user(self):
        response = self.tester.get('/delete/1', content_type='html/text')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), "User deleted successfully!")

    # Ensure that the correct information is returned for a user
    def test_get_user(self):
        response = self.tester.get('/user/1', content_type='html/text')
        self.assertEqual(response.status_code, 200)

    # Ensure that all users are returned
    def test_get_users(self):
        response = self.tester.get('/users', content_type='html/text')
        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
